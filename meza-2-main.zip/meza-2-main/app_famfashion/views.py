from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import Cliente, Mujer, Hombre, Ninas, Ninos, Pedido, Reseña, Usuario
from django.utils import timezone
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib import messages
from decimal import Decimal
# ==========================================
# DECORADOR PARA ADMINISTRADORES
# ==========================================
def admin_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_staff:
            messages.error(request, "Acceso denegado. Se requieren permisos de administrador.")
            return redirect('tienda_inicio')
        return view_func(request, *args, **kwargs)
    return wrapper

# ==========================================
# VISTAS PRINCIPALES
# ==========================================
def inicio_famfashion(request):
    """Página principal - Versión mejorada con selección de rol"""
    # Si ya está autenticado como staff, redirigir al dashboard de admin
    if request.user.is_authenticated and request.user.is_staff:
        return redirect('admin_dashboard')
    
    # Si ya tiene sesión de cliente, redirigir a la tienda
    if 'cliente_id' in request.session:
        return redirect('tienda_inicio')
    
    # Para todos los demás, mostrar página de inicio MEJORADA
    # Obtener algunos productos destacados para mostrar
    productos_mujer = Mujer.objects.all()[:4]
    productos_hombre = Hombre.objects.all()[:4]
    
    productos_destacados = []
    for producto in productos_mujer:
        productos_destacados.append({
            'id_producto': producto.id_producto,
            'nombre_producto': producto.nombre_producto,
            'descripcion': getattr(producto, 'descripcion', ''),
            'precio': producto.precio,
            'talla': getattr(producto, 'talla', 'Única'),
            'imagen': producto.imagen if hasattr(producto, 'imagen') and producto.imagen else None,
            'categoria': 'mujer'
        })
    
    for producto in productos_hombre:
        productos_destacados.append({
            'id_producto': producto.id_producto,
            'nombre_producto': producto.nombre_producto,
            'descripcion': getattr(producto, 'descripcion', ''),
            'precio': producto.precio,
            'talla': getattr(producto, 'talla', 'Única'),
            'imagen': producto.imagen if hasattr(producto, 'imagen') and producto.imagen else None,
            'categoria': 'hombre'
        })
    
    return render(request, 'app_famfashion/tienda/inicio.html', {
        'productos_destacados': productos_destacados
    })

def admin_dashboard(request):
    """Dashboard de administración"""
    if not request.user.is_authenticated or not request.user.is_staff:
        return redirect('tienda_inicio')
    
    stats = {
        'total_clientes': Cliente.objects.count(),
        'total_productos': Mujer.objects.count() + Hombre.objects.count() + Ninas.objects.count() + Ninos.objects.count(),
        'pedidos_pendientes': Pedido.objects.filter(estado='pendiente').count(),
        'total_pedidos': Pedido.objects.count(),
    }
    return render(request, 'app_famfashion/admin/dashboard.html', {'stats': stats})

# ==========================================
# VISTAS PARA LA TIENDA CLIENTE
# ==========================================
def tienda_inicio(request):
    """Página principal de la tienda para clientes"""
    # Obtener productos de cada categoría
    productos_mujer = Mujer.objects.all()[:2]
    productos_hombre = Hombre.objects.all()[:2]
    productos_ninas = Ninas.objects.all()[:2]
    productos_ninos = Ninos.objects.all()[:2]
    
    # Crear una lista unificada con estructura consistente
    productos_destacados = []
    
    for producto in productos_mujer:
        productos_destacados.append({
            'id_producto': producto.id_producto,
            'nombre_producto': producto.nombre_producto,
            'descripcion': getattr(producto, 'descripcion', ''),
            'precio': producto.precio,
            'talla': getattr(producto, 'talla', 'Única'),
            'imagen': producto.imagen if hasattr(producto, 'imagen') and producto.imagen else None,
            'categoria': 'mujer'
        })
    
    for producto in productos_hombre:
        productos_destacados.append({
            'id_producto': producto.id_producto,
            'nombre_producto': producto.nombre_producto,
            'descripcion': getattr(producto, 'descripcion', ''),
            'precio': producto.precio,
            'talla': getattr(producto, 'talla', 'Única'),
            'imagen': producto.imagen if hasattr(producto, 'imagen') and producto.imagen else None,
            'categoria': 'hombre'
        })
    
    for producto in productos_ninas:
        productos_destacados.append({
            'id_producto': producto.id_producto,
            'nombre_producto': producto.nombre_producto,
            'descripcion': getattr(producto, 'descripcion', ''),
            'precio': producto.precio,
            'talla': getattr(producto, 'talla', 'Única'),
            'imagen': producto.imagen if hasattr(producto, 'imagen') and producto.imagen else None,
            'categoria': 'ninas'
        })
    
    for producto in productos_ninos:
        productos_destacados.append({
            'id_producto': producto.id_producto,
            'nombre_producto': producto.nombre_producto,
            'descripcion': getattr(producto, 'descripcion', ''),
            'precio': producto.precio,
            'talla': getattr(producto, 'talla', 'Única'),
            'imagen': producto.imagen if hasattr(producto, 'imagen') and producto.imagen else None,
            'categoria': 'ninos'
        })
    
    # Debug info para tu sistema personalizado
    print("=" * 50)
    print("DEBUG SISTEMA PERSONALIZADO")
    print("=" * 50)
    print(f"Cliente ID en sesión: {request.session.get('cliente_id')}")
    print(f"Cliente Nombre: {request.session.get('cliente_nombre')}")
    print(f"Session Key: {request.session.session_key}")
    print("=" * 50)
    
    context = {
        'productos_destacados': productos_destacados,
        'cliente_autenticado': bool(request.session.get('cliente_id')),  # Pasar estado de autenticación
        'cliente_nombre': request.session.get('cliente_nombre', ''),
    }
    return render(request, 'app_famfashion/tienda/inicio.html', context)

def productos_todos(request):
    """Todos los productos para clientes"""
    productos = {
        'mujer': Mujer.objects.all(),
        'hombre': Hombre.objects.all(),
        'ninas': Ninas.objects.all(),
        'ninos': Ninos.objects.all(),
    }
    return render(request, 'app_famfashion/tienda/productos.html', {'productos': productos})

def productos_por_categoria(request, categoria):
    """Productos por categoría específica para clientes"""
    if categoria == 'mujer':
        productos = Mujer.objects.all()
    elif categoria == 'hombre':
        productos = Hombre.objects.all()
    elif categoria == 'ninas':
        productos = Ninas.objects.all()
    elif categoria == 'ninos':
        productos = Ninos.objects.all()
    else:
        productos = []
    
    return render(request, 'app_famfashion/tienda/categoria.html', {
        'categoria': categoria,
        'productos': productos
    })

def buscar_productos(request):
    """Búsqueda de productos para clientes"""
    query = request.GET.get('q', '')
    if query:
        productos_mujer = Mujer.objects.filter(
            Q(nombre_producto__icontains=query) | 
            Q(descripcion__icontains=query)
        )
        productos_hombre = Hombre.objects.filter(
            Q(nombre_producto__icontains=query) | 
            Q(descripcion__icontains=query)
        )
        productos_ninas = Ninas.objects.filter(
            Q(nombre_producto__icontains=query) | 
            Q(descripcion__icontains=query)
        )
        productos_ninos = Ninos.objects.filter(
            Q(nombre_producto__icontains=query) | 
            Q(descripcion__icontains=query)
        )
    else:
        productos_mujer = Mujer.objects.none()
        productos_hombre = Hombre.objects.none()
        productos_ninas = Ninas.objects.none()
        productos_ninos = Ninos.objects.none()
    
    return render(request, 'app_famfashion/tienda/buscar.html', {
        'query': query,
        'productos_mujer': productos_mujer,
        'productos_hombre': productos_hombre,
        'productos_ninas': productos_ninas,
        'productos_ninos': productos_ninos,
    })

# ==========================================
# AUTENTICACIÓN Y REGISTRO
# ==========================================
from django.contrib.auth.hashers import make_password

def registro_cliente(request):
    """Registro para clientes (usa el modelo Cliente)"""
    if request.method == 'POST':
        try:
            # Verificar si el email ya existe
            if Cliente.objects.filter(email=request.POST['email']).exists():
                messages.error(request, 'Este email ya está registrado.')
                return render(request, 'app_famfashion/tienda/registro.html')
            
            # Validar que las contraseñas coincidan (si tienes confirmación)
            password = request.POST['password']
            confirm_password = request.POST.get('confirm_password', '')
            
            if confirm_password and password != confirm_password:
                messages.error(request, 'Las contraseñas no coinciden.')
                return render(request, 'app_famfashion/tienda/registro.html')
            
            cliente = Cliente(
                nombre=request.POST['nombre'],
                apellido=request.POST['apellido'],
                email=request.POST['email'],
                telefono=request.POST.get('telefono', ''),
                calle=request.POST.get('calle', ''),
                numero_casa=request.POST.get('numero_casa', ''),
                colonia=request.POST.get('colonia', ''),
                ciudad=request.POST.get('ciudad', ''),
                codigo_postal=request.POST.get('codigo_postal', ''),
                descripcion_direccion=request.POST.get('descripcion_direccion', ''),
                metodo_pago=request.POST.get('metodo_pago', '')
            )
            
            # Encriptar la contraseña antes de guardar
            cliente.contraseña = make_password(password)
            cliente.save()
            
            messages.success(request, '¡Cuenta creada exitosamente! Ahora puedes iniciar sesión.')
            return redirect('login_cliente')
            
        except Exception as e:
            messages.error(request, f'Error al crear la cuenta: {str(e)}')
    
    return render(request, 'app_famfashion/tienda/registro.html')

from django.contrib.auth.hashers import check_password

def login_cliente(request):
    """Login para clientes"""
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        
        try:
            # Buscar cliente por email
            cliente = Cliente.objects.get(email=email)
            
            # Verificar contraseña usando check_password
            if check_password(password, cliente.contraseña):
                # Contraseña correcta - crear sesión
                request.session['cliente_id'] = cliente.id_cliente  # CAMBIADO: usar id_cliente
                request.session['cliente_nombre'] = f"{cliente.nombre} {cliente.apellido}"
                request.session['cliente_email'] = cliente.email
                
                messages.success(request, f'¡Bienvenido de nuevo, {cliente.nombre}!')
                return redirect('tienda_inicio')
            else:
                messages.error(request, 'Email o contraseña incorrectos.')
                
        except Cliente.DoesNotExist:
            messages.error(request, 'Email o contraseña incorrectos.')
        except Exception as e:
            messages.error(request, f'Error al iniciar sesión: {str(e)}')
    
    return render(request, 'app_famfashion/tienda/login.html')

def logout_cliente(request):
    """Logout para clientes"""
    if 'cliente_id' in request.session:
        nombre = request.session.get('cliente_nombre', '')
        request.session.flush()
        messages.success(request, f'¡Hasta pronto, {nombre}!')
    return redirect('tienda_inicio')

# ==========================================
# CARRITO DE COMPRAS (Sesión-based)
# ==========================================
def ver_carrito(request):
    """Ver carrito usando sesiones - VERSIÓN CORREGIDA CON DECIMAL"""
    carrito = request.session.get('carrito', {})
    items = []
    subtotal = Decimal('0.00')
    
    # Crear una copia del carrito para iterar
    carrito_copia = carrito.copy()
    
    for producto_id, item_data in carrito_copia.items():
        try:
            if item_data['tipo'] == 'mujer':
                producto = Mujer.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'hombre':
                producto = Hombre.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninas':
                producto = Ninas.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninos':
                producto = Ninos.objects.get(id_producto=item_data['producto_id'])
            else:
                # Tipo inválido, eliminar del carrito real
                if producto_id in carrito:
                    del carrito[producto_id]
                continue
                
            # Usar Decimal para los cálculos
            item_total = producto.precio * Decimal(item_data['cantidad'])
            items.append({
                'producto': producto,
                'cantidad': item_data['cantidad'],
                'tipo': item_data['tipo'],
                'clave': producto_id,
                'total': item_total
            })
            subtotal += item_total
            
        except Exception as e:
            # Producto no existe, eliminar del carrito real
            if producto_id in carrito:
                del carrito[producto_id]
            continue
    
    # Actualizar sesión solo si hubo cambios
    if carrito != request.session.get('carrito', {}):
        request.session['carrito'] = carrito
    
    # Calcular impuestos y total usando Decimal
    tasa_impuestos = Decimal('0.16')  # 16% como Decimal
    impuestos = subtotal * tasa_impuestos
    total = subtotal + impuestos
    
    return render(request, 'app_famfashion/tienda/carrito.html', {
        'items': items,
        'subtotal': subtotal,
        'impuestos': impuestos,
        'total': total
    })

def agregar_al_carrito(request, tipo_producto, id_producto):
    """Agregar producto al carrito (sesión-based)"""
    carrito = request.session.get('carrito', {})
    clave = f"{tipo_producto}_{id_producto}"
    
    if clave in carrito:
        carrito[clave]['cantidad'] += 1
    else:
        carrito[clave] = {
            'tipo': tipo_producto,
            'producto_id': id_producto,
            'cantidad': 1
        }
    
    request.session['carrito'] = carrito
    messages.success(request, 'Producto agregado al carrito.')
    return redirect('ver_carrito')

def actualizar_carrito(request):
    """Actualizar cantidades del carrito - SIN ARGUMENTOS"""
    if request.method == 'POST':
        carrito = request.session.get('carrito', {})
        cambios_realizados = False
        
        for clave, cantidad_str in request.POST.items():
            if clave.startswith('cantidad_'):
                producto_key = clave.replace('cantidad_', '')
                try:
                    nueva_cantidad = int(cantidad_str)
                    if nueva_cantidad > 0 and producto_key in carrito:
                        carrito[producto_key]['cantidad'] = nueva_cantidad
                        cambios_realizados = True
                    elif nueva_cantidad <= 0 and producto_key in carrito:
                        del carrito[producto_key]
                        cambios_realizados = True
                except ValueError:
                    continue
        
        if cambios_realizados:
            request.session['carrito'] = carrito
            messages.success(request, 'Carrito actualizado.')
        else:
            messages.info(request, 'No se realizaron cambios en el carrito.')
    
    return redirect('ver_carrito')

def eliminar_del_carrito(request, producto_key):
    """Eliminar producto del carrito - VERSIÓN CORREGIDA"""
    carrito = request.session.get('carrito', {})
    
    if producto_key in carrito:
        # Obtener nombre del producto antes de eliminar
        try:
            item_data = carrito[producto_key]
            if item_data['tipo'] == 'mujer':
                producto = Mujer.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'hombre':
                producto = Hombre.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninas':
                producto = Ninas.objects.get(id_producto=item_data['producto_id'])
            elif item_data['tipo'] == 'ninos':
                producto = Ninos.objects.get(id_producto=item_data['producto_id'])
            producto_nombre = producto.nombre_producto
        except:
            producto_nombre = 'Producto'
        
        del carrito[producto_key]
        request.session['carrito'] = carrito
        messages.success(request, f'{producto_nombre} eliminado del carrito.')
    
    return redirect('ver_carrito')
# ==========================================
# CHECKOUT Y PEDIDOS CLIENTES
# ==========================================
def checkout(request):
    """Checkout para clientes"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para realizar un pedido.')
        return redirect('login_cliente')
    
    carrito = request.session.get('carrito', {})
    if not carrito:
        messages.warning(request, 'Tu carrito está vacío.')
        return redirect('ver_carrito')
    
    # DEBUG DEL CARRITO
    print("=== DEBUG CHECKOUT ===")
    print(f"Carrito: {carrito}")
    print(f"Items en carrito: {len(carrito)}")
    
    try:
        cliente = Cliente.objects.get(id_cliente=request.session['cliente_id'])
        print(f"Cliente encontrado: {cliente.id_cliente} - {cliente.nombre}")
    except Cliente.DoesNotExist:
        messages.error(request, 'Cliente no encontrado.')
        return redirect('login_cliente')
    
    # Calcular totales
    subtotal = Decimal('0.00')
    items = []
    
    for producto_key, item_data in carrito.items():
        try:
            print(f"Procesando item: {producto_key} - {item_data}")
            
            if item_data['tipo'] == 'mujer':
                producto = Mujer.objects.get(id_producto=item_data['producto_id'])
                precio = producto.precio  # CAMBIO: usar precio en lugar de precio_producto
            elif item_data['tipo'] == 'hombre':
                producto = Hombre.objects.get(id_producto=item_data['producto_id'])
                precio = producto.precio  # CAMBIO
            elif item_data['tipo'] == 'ninas':
                producto = Ninas.objects.get(id_producto=item_data['producto_id'])
                precio = producto.precio  # CAMBIO
            elif item_data['tipo'] == 'ninos':
                producto = Ninos.objects.get(id_producto=item_data['producto_id'])
                precio = producto.precio  # CAMBIO
            else:
                print(f"Tipo de producto no válido: {item_data['tipo']}")
                continue
                
            item_total = precio * Decimal(item_data['cantidad'])
            items.append({
                'producto': producto,
                'cantidad': item_data['cantidad'],
                'tipo': item_data['tipo'],
                'total': item_total,
                'precio': precio  # AGREGADO
            })
            subtotal += item_total
            
            print(f"✅ Producto encontrado: {producto.nombre_producto} - ${precio}")
            
        except Exception as e:
            print(f"❌ Error procesando item {producto_key}: {str(e)}")
            continue
    
    print(f"Items procesados: {len(items)}")
    print(f"Subtotal: ${subtotal}")
    
    tasa_impuestos = Decimal('0.16')
    impuestos = subtotal * tasa_impuestos
    total = subtotal + impuestos
    
    if request.method == 'POST':
        print("=== PROCESANDO PEDIDO POST ===")
        try:
            # Crear pedido para cada item
            pedidos_creados = 0
            for item in items:
                print(f"Creando pedido para: {item['producto'].nombre_producto}")
                
                pedido = Pedido(
                    cliente_id=request.session['cliente_id'],
                    nombre_producto=item['producto'].nombre_producto,
                    cantidad=item['cantidad'],
                    precio_unitario=item['precio'],  # CAMBIO: usar item['precio']
                    total=item['total'],
                    metodo_pago=request.POST.get('metodo_pago', 'efectivo'),
                    estado='pendiente',
                    direccion=f"{cliente.calle or ''} {cliente.numero_casa or ''}, {cliente.colonia or ''}, {cliente.ciudad or ''}".strip()
                )
                
                # Asignar producto según tipo
                if item['tipo'] == 'mujer':
                    pedido.producto_mujer = item['producto']
                elif item['tipo'] == 'hombre':
                    pedido.producto_hombre = item['producto']
                elif item['tipo'] == 'ninas':
                    pedido.producto_ninas = item['producto']
                elif item['tipo'] == 'ninos':
                    pedido.producto_ninos = item['producto']
                
                pedido.save()
                pedidos_creados += 1
                print(f"✅ PEDIDO CREADO: #{pedido.id_pedido} - {pedido.nombre_producto}")
            
            print(f"Total de pedidos creados: {pedidos_creados}")
            
            # Limpiar carrito
            request.session['carrito'] = {}
            request.session.modified = True
            
            messages.success(request, f'¡Pedido realizado exitosamente! Se crearon {pedidos_creados} pedidos.')
            return redirect('mis_pedidos')
            
        except Exception as e:
            print(f"❌ ERROR GRAVE en checkout: {str(e)}")
            messages.error(request, f'Error al procesar el pedido: {str(e)}')
    
    return render(request, 'app_famfashion/tienda/checkout.html', {
        'cliente': cliente,
        'items': items,
        'subtotal': subtotal,
        'impuestos': impuestos,
        'total': total
    })

def confirmacion_pedido(request):
    """Confirmación de pedido"""
    return render(request, 'app_famfashion/tienda/confirmacion.html')

def mis_pedidos(request):
    """Pedidos del cliente"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para ver tus pedidos.')
        return redirect('login_cliente')
    
    try:
        # OPCIÓN CORRECTA para tu modelo: usar cliente_id
        pedidos = Pedido.objects.filter(cliente_id=request.session['cliente_id']).order_by('-fecha_pedido')
        
        # DEBUG
        print(f"Buscando pedidos para cliente_id: {request.session['cliente_id']}")
        print(f"Pedidos encontrados: {pedidos.count()}")
        
        return render(request, 'app_famfashion/tienda/mis_pedidos.html', {
            'pedidos': pedidos
        })
        
    except Exception as e:
        messages.error(request, f'Error al cargar pedidos: {str(e)}')
        return redirect('tienda_inicio')
# ==========================================
# PERFIL CLIENTE
# ==========================================
def perfil_usuario(request):
    """Perfil del cliente"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para acceder a tu perfil.')
        return redirect('login_cliente')
    
    try:
        # CAMBIO AQUÍ: usar id_cliente en lugar de id
        cliente = Cliente.objects.get(id_cliente=request.session['cliente_id'])
        
        if request.method == 'POST':
            cliente.nombre = request.POST['nombre']
            cliente.apellido = request.POST['apellido']
            cliente.email = request.POST['email']
            cliente.telefono = request.POST.get('telefono', '')
            cliente.calle = request.POST.get('calle', '')
            cliente.numero_casa = request.POST.get('numero_casa', '')
            cliente.colonia = request.POST.get('colonia', '')
            cliente.ciudad = request.POST.get('ciudad', '')
            cliente.codigo_postal = request.POST.get('codigo_postal', '')
            cliente.descripcion_direccion = request.POST.get('descripcion_direccion', '')
            cliente.metodo_pago = request.POST.get('metodo_pago', '')
            
            # Actualizar contraseña solo si se proporciona una nueva
            nueva_password = request.POST.get('password', '')
            if nueva_password:
                cliente.contraseña = make_password(nueva_password)  # Encriptar nueva contraseña
            
            cliente.save()
            
            # Actualizar sesión
            request.session['cliente_nombre'] = f"{cliente.nombre} {cliente.apellido}"
            request.session['cliente_email'] = cliente.email
            
            messages.success(request, 'Perfil actualizado exitosamente.')
            return redirect('perfil_usuario')
        
        return render(request, 'app_famfashion/tienda/perfil.html', {'cliente': cliente})
        
    except Cliente.DoesNotExist:
        messages.error(request, 'Cliente no encontrado.')
        return redirect('tienda_inicio')
# ==========================================
# VISTAS PRINCIPALES
# ==========================================
def inicio_famfashion(request):
    return render(request, 'app_famfashion/inicio.html')
# ==========================================
# VISTAS PARA CLIENTES
# ==========================================
def agregar_cliente(request):
    if request.method == 'POST':
        cliente = Cliente(
            nombre=request.POST['nombre'],
            apellido=request.POST['apellido'],
            email=request.POST['email'],
            telefono=request.POST['telefono'],
            calle=request.POST['calle'],
            numero_casa=request.POST['numero_casa'],
            colonia=request.POST['colonia'],
            ciudad=request.POST['ciudad'],
            codigo_postal=request.POST['codigo_postal'],
            descripcion_direccion=request.POST['descripcion_direccion'],
            metodo_pago=request.POST['metodo_pago']
        )
        # Encriptar contraseña
        cliente.contraseña = make_password(request.POST['contraseña'])
        cliente.save()
        return redirect('ver_clientes')
    return render(request, 'app_famfashion/clientes/agregar_cliente.html')

def ver_clientes(request):
    clientes = Cliente.objects.all()
    return render(request, 'app_famfashion/clientes/ver_clientes.html', {'clientes': clientes})

def actualizar_cliente(request, id_cliente):
    cliente = get_object_or_404(Cliente, id=id_cliente)
    if request.method == 'POST':
        cliente.nombre = request.POST['nombre']
        cliente.apellido = request.POST['apellido']
        cliente.email = request.POST['email']
        cliente.telefono = request.POST['telefono']
        cliente.calle = request.POST['calle']
        cliente.numero_casa = request.POST['numero_casa']
        cliente.colonia = request.POST['colonia']
        cliente.ciudad = request.POST['ciudad']
        cliente.codigo_postal = request.POST['codigo_postal']
        cliente.descripcion_direccion = request.POST['descripcion_direccion']
        cliente.metodo_pago = request.POST['metodo_pago']
        
        # Actualizar contraseña solo si se proporciona una nueva
        nueva_password = request.POST.get('contraseña', '')
        if nueva_password:
            cliente.contraseña = make_password(nueva_password)
        
        cliente.save()
        return redirect('ver_clientes')
    return render(request, 'app_famfashion/clientes/actualizar_cliente.html', {'cliente': cliente})

def borrar_cliente(request, id_cliente):
    cliente = get_object_or_404(Cliente, id_cliente=id_cliente)
    if request.method == 'POST':
        cliente.delete()
        return redirect('ver_clientes')
    return render(request, 'app_famfashion/clientes/borrar_cliente.html', {'cliente': cliente})

# ==========================================
# VISTAS PARA PRODUCTOS MUJER
# ==========================================
def agregar_mujer(request):
    if request.method == 'POST':
        mujer = Mujer(
            nombre_producto=request.POST['nombre_producto'],
            descripcion=request.POST['descripcion'],
            talla=request.POST['talla'],
            color=request.POST['color'],
            precio=request.POST['precio'],
            stock=request.POST['stock'],
            material=request.POST['material'],
            temporada=request.POST['temporada'],
            tipo=request.POST['tipo']
        )
        if 'imagen' in request.FILES:
            mujer.imagen = request.FILES['imagen']
        mujer.save()
        return redirect('ver_mujer')
    return render(request, 'app_famfashion/productos/mujer/agregar_mujer.html')

def ver_mujer(request):
    productos = Mujer.objects.all()
    return render(request, 'app_famfashion/productos/mujer/ver_mujer.html', {'productos': productos})

def actualizar_mujer(request, id_producto):
    producto = get_object_or_404(Mujer, id_producto=id_producto)
    if request.method == 'POST':
        producto.nombre_producto = request.POST['nombre_producto']
        producto.descripcion = request.POST['descripcion']
        producto.talla = request.POST['talla']
        producto.color = request.POST['color']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.material = request.POST['material']
        producto.temporada = request.POST['temporada']
        producto.tipo = request.POST['tipo']
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']
        producto.save()
        return redirect('ver_mujer')
    return render(request, 'app_famfashion/productos/mujer/actualizar_mujer.html', {'producto': producto})

def borrar_mujer(request, id_producto):
    producto = get_object_or_404(Mujer, id_producto=id_producto)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_mujer')
    return render(request, 'app_famfashion/productos/mujer/borrar_mujer.html', {'producto': producto})

# ==========================================
# VISTAS PARA PRODUCTOS HOMBRE
# ==========================================
def agregar_hombre(request):
    if request.method == 'POST':
        hombre = Hombre(
            nombre_producto=request.POST['nombre_producto'],
            descripcion=request.POST['descripcion'],
            talla=request.POST['talla'],
            color=request.POST['color'],
            precio=request.POST['precio'],
            stock=request.POST['stock'],
            material=request.POST['material'],
            temporada=request.POST['temporada'],
            tipo=request.POST['tipo']
        )
        if 'imagen' in request.FILES:
            hombre.imagen = request.FILES['imagen']
        hombre.save()
        return redirect('ver_hombre')
    return render(request, 'app_famfashion/productos/hombre/agregar_hombre.html')

def ver_hombre(request):
    productos = Hombre.objects.all()
    return render(request, 'app_famfashion/productos/hombre/ver_hombre.html', {'productos': productos})

def actualizar_hombre(request, id_producto):
    producto = get_object_or_404(Hombre, id_producto=id_producto)
    if request.method == 'POST':
        producto.nombre_producto = request.POST['nombre_producto']
        producto.descripcion = request.POST['descripcion']
        producto.talla = request.POST['talla']
        producto.color = request.POST['color']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.material = request.POST['material']
        producto.temporada = request.POST['temporada']
        producto.tipo = request.POST['tipo']
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']
        producto.save()
        return redirect('ver_hombre')
    return render(request, 'app_famfashion/productos/hombre/actualizar_hombre.html', {'producto': producto})

def borrar_hombre(request, id_producto):
    producto = get_object_or_404(Hombre, id_producto=id_producto)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_hombre')
    return render(request, 'app_famfashion/productos/hombre/borrar_hombre.html', {'producto': producto})

# ==========================================
# VISTAS PARA PEDIDOS
# ==========================================
def ver_pedidos(request):
    pedidos = Pedido.objects.all()
    return render(request, 'app_famfashion/pedidos/ver_pedidos.html', {'pedidos': pedidos})

def detalle_pedido(request, id_pedido):
    pedido = get_object_or_404(Pedido, id_pedido=id_pedido)
    return render(request, 'app_famfashion/pedidos/detalle_pedido.html', {'pedido': pedido})

def actualizar_estado_pedido(request, id_pedido):
    pedido = get_object_or_404(Pedido, id_pedido=id_pedido)
    if request.method == 'POST':
        pedido.estado = request.POST['estado']
        pedido.save()
        return redirect('ver_pedidos')
    return render(request, 'app_famfashion/pedidos/actualizar_estado_pedido.html', {'pedido': pedido})

# ==========================================
# VISTAS PARA RESEÑAS
# ==========================================
def ver_resenas(request):
    resenas = Reseña.objects.all()
    return render(request, 'app_famfashion/resenas/ver_resenas.html', {'resenas': resenas})

def agregar_resena(request):
    if request.method == 'POST':
        try:
            # Obtener el primer cliente disponible o crear una reseña sin cliente
            cliente = Cliente.objects.first()  # O puedes hacer un select para que el usuario elija
            
            resena = Reseña(
                id_cliente=cliente,  # Asignar un cliente
                calificacion=request.POST['calificacion'],
                comentario=request.POST['comentario']
            )
            if 'foto_producto' in request.FILES:
                resena.foto_producto = request.FILES['foto_producto']
            resena.save()
            return redirect('ver_resenas')
        except Exception as e:
            print(f"Error al crear reseña: {e}")
            # Manejar el error apropiadamente
    
    # Pasar clientes al template para selección
    clientes = Cliente.objects.all()
    return render(request, 'app_famfashion/resenas/agregar_resena.html', {'clientes': clientes})
def borrar_resena(request, id_reseña):
    resena = get_object_or_404(Reseña, id_reseña=id_reseña)
    if request.method == 'POST':
        resena.delete()
        return redirect('ver_resenas')
    return render(request, 'app_famfashion/resenas/borrar_resena.html', {'resena': resena})

# ==========================================
# VISTAS PARA PRODUCTOS NIÑAS
# ==========================================
def agregar_ninas(request):
    if request.method == 'POST':
        ninas = Ninas(
            nombre_producto=request.POST['nombre_producto'],
            descripcion=request.POST['descripcion'],
            talla=request.POST['talla'],
            color=request.POST['color'],
            precio=request.POST['precio'],
            stock=request.POST['stock'],
            material=request.POST['material'],
            temporada=request.POST['temporada'],
            tipo=request.POST['tipo'],
            edad_recomendada=request.POST['edad_recomendada']
        )
        if 'imagen' in request.FILES:
            ninas.imagen = request.FILES['imagen']
        ninas.save()
        return redirect('ver_ninas')
    return render(request, 'app_famfashion/productos/ninas/agregar_ninas.html')

def ver_ninas(request):
    productos = Ninas.objects.all()
    return render(request, 'app_famfashion/productos/ninas/ver_ninas.html', {'productos': productos})

def actualizar_ninas(request, id_producto):
    producto = get_object_or_404(Ninas, id_producto=id_producto)
    if request.method == 'POST':
        producto.nombre_producto = request.POST['nombre_producto']
        producto.descripcion = request.POST['descripcion']
        producto.talla = request.POST['talla']
        producto.color = request.POST['color']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.material = request.POST['material']
        producto.temporada = request.POST['temporada']
        producto.tipo = request.POST['tipo']
        producto.edad_recomendada = request.POST['edad_recomendada']
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']
        producto.save()
        return redirect('ver_ninas')
    return render(request, 'app_famfashion/productos/ninas/actualizar_ninas.html', {'producto': producto})

def borrar_ninas(request, id_producto):
    producto = get_object_or_404(Ninas, id_producto=id_producto)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_ninas')
    return render(request, 'app_famfashion/productos/ninas/borrar_ninas.html', {'producto': producto})

# ==========================================
# VISTAS PARA PRODUCTOS NIÑOS
# ==========================================
def agregar_ninos(request):
    if request.method == 'POST':
        ninos = Ninos(
            nombre_producto=request.POST['nombre_producto'],
            descripcion=request.POST['descripcion'],
            talla=request.POST['talla'],
            color=request.POST['color'],
            precio=request.POST['precio'],
            stock=request.POST['stock'],
            material=request.POST['material'],
            temporada=request.POST['temporada'],
            tipo=request.POST['tipo'],
            edad_recomendada=request.POST['edad_recomendada']
        )
        if 'imagen' in request.FILES:
            ninos.imagen = request.FILES['imagen']
        ninos.save()
        return redirect('ver_ninos')
    return render(request, 'app_famfashion/productos/ninos/agregar_ninos.html')

def ver_ninos(request):
    productos = Ninos.objects.all()
    return render(request, 'app_famfashion/productos/ninos/ver_ninos.html', {'productos': productos})

def actualizar_ninos(request, id_producto):
    producto = get_object_or_404(Ninos, id_producto=id_producto)
    if request.method == 'POST':
        producto.nombre_producto = request.POST['nombre_producto']
        producto.descripcion = request.POST['descripcion']
        producto.talla = request.POST['talla']
        producto.color = request.POST['color']
        producto.precio = request.POST['precio']
        producto.stock = request.POST['stock']
        producto.material = request.POST['material']
        producto.temporada = request.POST['temporada']
        producto.tipo = request.POST['tipo']
        producto.edad_recomendada = request.POST['edad_recomendada']
        if 'imagen' in request.FILES:
            producto.imagen = request.FILES['imagen']
        producto.save()
        return redirect('ver_ninos')
    return render(request, 'app_famfashion/productos/ninos/actualizar_ninos.html', {'producto': producto})

def borrar_ninos(request, id_producto):
    producto = get_object_or_404(Ninos, id_producto=id_producto)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_ninos')
    return render(request, 'app_famfashion/productos/ninos/borrar_ninos.html', {'producto': producto})

# ==========================================
# VISTA PARA BORRAR PEDIDO
# ==========================================
def borrar_pedido(request, id_pedido):
    pedido = get_object_or_404(Pedido, id_pedido=id_pedido)
    if request.method == 'POST':
        pedido.delete()
        return redirect('ver_pedidos')
    return render(request, 'app_famfashion/pedidos/borrar_pedido.html', {'pedido': pedido})
def agregar_pedido(request):
    if request.method == 'POST':
        # Obtener el cliente
        cliente_id = request.POST.get('id_cliente')
        cliente = None
        if cliente_id:
            cliente = Cliente.objects.get(id_cliente=cliente_id)
        
        # Calcular total
        cantidad = int(request.POST['cantidad'])
        precio_unitario = float(request.POST['precio_unitario'])
        total = cantidad * precio_unitario
        
        pedido = Pedido(
            id_cliente=cliente,
            nombre_producto=request.POST['nombre_producto'],
            cantidad=cantidad,
            precio_unitario=precio_unitario,
            total=total,
            metodo_pago=request.POST['metodo_pago'],
            estado=request.POST['estado'],
            direccion=request.POST['direccion']
        )
        pedido.save()
        return redirect('ver_pedidos')
    
    # Obtener datos para el formulario
    clientes = Cliente.objects.all()
    productos_mujer = Mujer.objects.all()
    productos_hombre = Hombre.objects.all()
    productos_ninas = Ninas.objects.all()
    productos_ninos = Ninos.objects.all()
    
    context = {
        'clientes': clientes,
        'productos_mujer': productos_mujer,
        'productos_hombre': productos_hombre,
        'productos_ninas': productos_ninas,
        'productos_ninos': productos_ninos,
    }
    return render(request, 'app_famfashion/pedidos/agregar_pedido.html', context)


# ==========================================
# VISTA PARA ACTUALIZAR RESEÑA
# ==========================================
def ver_resenas(request):
    try:
        resenas = Reseña.objects.all()
        # Verificar que todas las reseñas tengan id válido
        for resena in resenas:
            print(f"Reseña ID: {resena.id_reseña}, Cliente: {resena.id_cliente}")
    except Exception as e:
        print(f"Error al cargar reseñas: {e}")
        resenas = []
    
    return render(request, 'app_famfashion/resenas/ver_resenas.html', {'resenas': resenas})

def actualizar_resena(request, id_reseña):  # Asegúrate de que el parámetro sea id_reseña
    resena = get_object_or_404(Reseña, id_reseña=id_reseña)
    if request.method == 'POST':
        resena.calificacion = request.POST['calificacion']
        resena.comentario = request.POST['comentario']
        if 'foto_producto' in request.FILES:
            resena.foto_producto = request.FILES['foto_producto']
        resena.save()
        return redirect('ver_resenas')
    
    clientes = Cliente.objects.all()
    return render(request, 'app_famfashion/resenas/actualizar_resena.html', {
        'resena': resena,
        'clientes': clientes
    })

def admin_dashboard(request):
    """Dashboard de administración"""
    if not request.user.is_authenticated or not request.user.is_staff:
        return redirect('tienda_inicio')
    
    stats = {
        'total_clientes': Cliente.objects.count(),
        'total_productos': Mujer.objects.count() + Hombre.objects.count() + Ninas.objects.count() + Ninos.objects.count(),
        'pedidos_pendientes': Pedido.objects.filter(estado='pendiente').count(),
        'total_pedidos': Pedido.objects.count(),
        'mujer_count': Mujer.objects.count(),
        'hombre_count': Hombre.objects.count(),
        'ninas_count': Ninas.objects.count(),
        'ninos_count': Ninos.objects.count(),
        'total_registros': Cliente.objects.count() + Mujer.objects.count() + Hombre.objects.count() + 
                            Ninas.objects.count() + Ninos.objects.count() + Pedido.objects.count() + 
                            Reseña.objects.count(),
    }
    return render(request, 'app_famfashion/admin/dashboard.html', {'stats': stats})

# ==========================================
# VISTAS PARA FAVORITOS (Sesión-based)
# ==========================================
def ver_favoritos(request):
    """Ver favoritos del cliente"""
    if 'cliente_id' not in request.session:
        messages.info(request, 'Inicia sesión para ver tus favoritos')
        return redirect('login_cliente')
    
    favoritos = request.session.get('favoritos', {})
    productos_favoritos = []
    
    # Reconstruir favoritos desde la sesión
    for clave, datos in favoritos.items():
        try:
            if datos['tipo'] == 'mujer':
                producto = Mujer.objects.get(id_producto=datos['producto_id'])
            elif datos['tipo'] == 'hombre':
                producto = Hombre.objects.get(id_producto=datos['producto_id'])
            elif datos['tipo'] == 'ninas':
                producto = Ninas.objects.get(id_producto=datos['producto_id'])
            elif datos['tipo'] == 'ninos':
                producto = Ninos.objects.get(id_producto=datos['producto_id'])
            else:
                continue
            
            # Convertir la fecha de string ISO a objeto datetime
            fecha_agregado = None
            if 'fecha_agregado' in datos:
                try:
                    from django.utils.dateparse import parse_datetime
                    fecha_agregado = parse_datetime(datos['fecha_agregado'])
                except:
                    # Si no se puede parsear, usar la fecha actual
                    from django.utils import timezone
                    fecha_agregado = timezone.now()
                
            productos_favoritos.append({
                'producto': producto,
                'tipo': datos['tipo'],
                'clave': clave,
                'fecha_agregado': fecha_agregado
            })
            
        except Exception as e:
            # Si el producto no existe, remover de favoritos
            continue
    
    return render(request, 'app_famfashion/tienda/favoritos.html', {
        'favoritos': productos_favoritos
    })

def agregar_favorito(request, tipo_producto, id_producto):
    """Agregar producto a favoritos"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para agregar a favoritos')
        return redirect('login_cliente')
    
    favoritos = request.session.get('favoritos', {})
    clave = f"{tipo_producto}_{id_producto}"
    
    try:
        # Verificar que el producto existe
        if tipo_producto == 'mujer':
            producto = Mujer.objects.get(id_producto=id_producto)
        elif tipo_producto == 'hombre':
            producto = Hombre.objects.get(id_producto=id_producto)
        elif tipo_producto == 'ninas':
            producto = Ninas.objects.get(id_producto=id_producto)
        elif tipo_producto == 'ninos':
            producto = Ninos.objects.get(id_producto=id_producto)
        else:
            messages.error(request, 'Tipo de producto no válido')
            return redirect('productos_todos')
        
        if clave not in favoritos:
            favoritos[clave] = {
                'tipo': tipo_producto,
                'producto_id': id_producto,
                'fecha_agregado': timezone.now().isoformat()
            }
            request.session['favoritos'] = favoritos
            messages.success(request, f'"{producto.nombre_producto}" agregado a favoritos')
        else:
            messages.info(request, f'"{producto.nombre_producto}" ya está en tus favoritos')
            
    except Exception as e:
        messages.error(request, 'Error al agregar a favoritos')
    
    # Redirigir a la página anterior
    return redirect(request.META.get('HTTP_REFERER', 'tienda_inicio'))

def eliminar_favorito(request, clave_favorito):
    """Eliminar producto de favoritos"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para gestionar favoritos')
        return redirect('login_cliente')
    
    favoritos = request.session.get('favoritos', {})
    
    if clave_favorito in favoritos:
        # Obtener nombre del producto para el mensaje
        datos = favoritos[clave_favorito]
        try:
            if datos['tipo'] == 'mujer':
                producto = Mujer.objects.get(id_producto=datos['producto_id'])
            elif datos['tipo'] == 'hombre':
                producto = Hombre.objects.get(id_producto=datos['producto_id'])
            elif datos['tipo'] == 'ninas':
                producto = Ninas.objects.get(id_producto=datos['producto_id'])
            elif datos['tipo'] == 'ninos':
                producto = Ninos.objects.get(id_producto=datos['producto_id'])
            
            producto_nombre = producto.nombre_producto
        except:
            producto_nombre = "Producto"
        
        del favoritos[clave_favorito]
        request.session['favoritos'] = favoritos
        messages.success(request, f'"{producto_nombre}" eliminado de favoritos')
    else:
        messages.error(request, 'Producto no encontrado en favoritos')
    
    return redirect('ver_favoritos')

# ==========================================
# VISTAS PARA RESEÑAS (CLIENTES)
# ==========================================
def ver_resenas_cliente(request):
    """Ver reseñas para clientes (pública)"""
    try:
        # CORREGIDO: usar 'fecha' en lugar de 'fecha_creacion'
        reseñas = Reseña.objects.all().order_by('-fecha')[:10]  # Últimas 10 reseñas
    except Exception as e:
        print(f"Error al cargar reseñas: {e}")
        reseñas = []
    
    return render(request, 'app_famfashion/tienda/resenas_cliente.html', {
        'reseñas': reseñas
    })

def agregar_resena_cliente(request):
    """Agregar reseña para clientes con selección de producto"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para agregar una reseña')
        return redirect('login_cliente')
    
    # Obtener productos de todas las categorías
    productos_mujer = Mujer.objects.all()[:50]
    productos_hombre = Hombre.objects.all()[:50]
    productos_ninas = Ninas.objects.all()[:50]
    productos_ninos = Ninos.objects.all()[:50]
    
    if request.method == 'POST':
        try:
            cliente_id = request.session['cliente_id']
            cliente = Cliente.objects.get(id_cliente=cliente_id)
            
            # Obtener el usuario
            usuario = None
            try:
                usuario = Usuario.objects.get(email=cliente.email)
            except Usuario.DoesNotExist:
                try:
                    usuario = Usuario.objects.get(first_name=cliente.nombre, last_name=cliente.apellido)
                except Usuario.DoesNotExist:
                    # Crear un usuario básico si no existe
                    usuario = Usuario.objects.create(
                        username=cliente.email,
                        email=cliente.email,
                        first_name=cliente.nombre,
                        last_name=cliente.apellido,
                        password='temp_password'  # Contraseña temporal
                    )
                    messages.info(request, 'Se creó un perfil de usuario temporal para tu reseña')
            
            # Validar campos obligatorios
            tipo_producto = request.POST.get('tipo_producto')
            producto_id = request.POST.get('producto_id')
            calificacion = request.POST.get('calificacion')
            comentario = request.POST.get('comentario')
            
            if not all([tipo_producto, producto_id, calificacion, comentario]):
                messages.error(request, 'Todos los campos obligatorios deben ser completados')
                return render(request, 'app_famfashion/tienda/agregar_resena_cliente.html', {
                    'productos_mujer': productos_mujer,
                    'productos_hombre': productos_hombre,
                    'productos_ninas': productos_ninas,
                    'productos_ninos': productos_ninos,
                })
            
            # Crear la reseña
            nueva_resena = Reseña(
                usuario=usuario,
                calificacion=calificacion,
                comentario=comentario,
            )
            
            # Asignar el producto según la selección
            if tipo_producto == 'mujer':
                nueva_resena.producto_mujer = Mujer.objects.get(id_producto=producto_id)
            elif tipo_producto == 'hombre':
                nueva_resena.producto_hombre = Hombre.objects.get(id_producto=producto_id)
            elif tipo_producto == 'ninas':
                nueva_resena.producto_ninas = Ninas.objects.get(id_producto=producto_id)
            elif tipo_producto == 'ninos':
                nueva_resena.producto_ninos = Ninos.objects.get(id_producto=producto_id)
            
            # Manejar la foto si se subió
            if 'foto_producto' in request.FILES:
                nueva_resena.foto_producto = request.FILES['foto_producto']
            
            nueva_resena.save()
            messages.success(request, '¡Reseña agregada exitosamente!')
            return redirect('ver_resenas_cliente')
            
        except Mujer.DoesNotExist:
            messages.error(request, 'El producto seleccionado no existe en la categoría Mujer')
        except Hombre.DoesNotExist:
            messages.error(request, 'El producto seleccionado no existe en la categoría Hombre')
        except Ninas.DoesNotExist:
            messages.error(request, 'El producto seleccionado no existe en la categoría Niñas')
        except Ninos.DoesNotExist:
            messages.error(request, 'El producto seleccionado no existe en la categoría Niños')
        except Exception as e:
            messages.error(request, f'Error al agregar reseña: {str(e)}')
            print(f"DEBUG - Error detallado: {e}")
    
    context = {
        'productos_mujer': productos_mujer,
        'productos_hombre': productos_hombre,
        'productos_ninas': productos_ninas,
        'productos_ninos': productos_ninos,
    }
    return render(request, 'app_famfashion/tienda/agregar_resena_cliente.html', context)


def mis_resenas_cliente(request):
    """Ver las reseñas del cliente actual"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para ver tus reseñas')
        return redirect('login_cliente')
    
    try:
        cliente_id = request.session['cliente_id']
        cliente = Cliente.objects.get(id_cliente=cliente_id)
        
        # Obtener el usuario asociado al cliente
        try:
            usuario = Usuario.objects.get(email=cliente.email)
            # CORREGIDO: filtrar por 'usuario' en lugar de 'id_cliente' y usar 'fecha'
            mis_resenas = Reseña.objects.filter(usuario=usuario).order_by('-fecha')
        except Usuario.DoesNotExist:
            mis_resenas = []
            messages.info(request, 'No se encontró un usuario asociado a tu cuenta')
        
    except Exception as e:
        print(f"Error al cargar reseñas del cliente: {e}")
        mis_resenas = []
        messages.error(request, 'Error al cargar tus reseñas')
    
    return render(request, 'app_famfashion/tienda/mis_resenas.html', {
        'mis_resenas': mis_resenas
    })

def editar_resena_cliente(request, id_reseña):
    """Editar reseña del cliente"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para editar reseñas')
        return redirect('login_cliente')
    
    try:
        # Obtener la reseña a editar
        reseña = Reseña.objects.get(id_reseña=id_reseña)
        
        # Verificar que la reseña pertenece al cliente actual
        cliente_id = request.session['cliente_id']
        cliente = Cliente.objects.get(id_cliente=cliente_id)
        usuario_cliente = Usuario.objects.get(email=cliente.email)
        
        if reseña.usuario != usuario_cliente:
            messages.error(request, 'No tienes permiso para editar esta reseña')
            return redirect('mis_resenas_cliente')
        
        if request.method == 'POST':
            # Actualizar la reseña
            reseña.calificacion = request.POST['calificacion']
            reseña.comentario = request.POST['comentario']
            
            if 'foto_producto' in request.FILES:
                reseña.foto_producto = request.FILES['foto_producto']
            
            reseña.fecha = timezone.now()  # Actualizar fecha de modificación
            reseña.save()
            
            messages.success(request, '¡Reseña actualizada exitosamente!')
            return redirect('mis_resenas_cliente')
        
        # Obtener productos para mostrar (opcional, si quieres permitir cambiar producto)
        productos_mujer = Mujer.objects.all()[:20]
        productos_hombre = Hombre.objects.all()[:20]
        productos_ninas = Ninas.objects.all()[:20]
        productos_ninos = Ninos.objects.all()[:20]
        
        context = {
            'reseña': reseña,
            'productos_mujer': productos_mujer,
            'productos_hombre': productos_hombre,
            'productos_ninas': productos_ninas,
            'productos_ninos': productos_ninos,
        }
        return render(request, 'app_famfashion/tienda/editar_resena.html', context)
        
    except Reseña.DoesNotExist:
        messages.error(request, 'La reseña no existe')
        return redirect('mis_resenas_cliente')
    except Exception as e:
        messages.error(request, f'Error al editar reseña: {str(e)}')
        return redirect('mis_resenas_cliente')
    
def eliminar_resena_cliente(request, id_reseña):
    """Eliminar reseña del cliente"""
    if 'cliente_id' not in request.session:
        messages.error(request, 'Debes iniciar sesión para eliminar reseñas')
        return redirect('login_cliente')
    
    try:
        # Obtener la reseña a eliminar
        reseña = Reseña.objects.get(id_reseña=id_reseña)
        
        # Verificar que la reseña pertenece al cliente actual
        cliente_id = request.session['cliente_id']
        cliente = Cliente.objects.get(id_cliente=cliente_id)
        usuario_cliente = Usuario.objects.get(email=cliente.email)
        
        if reseña.usuario != usuario_cliente:
            messages.error(request, 'No tienes permiso para eliminar esta reseña')
            return redirect('mis_resenas_cliente')
        
        # Eliminar la reseña
        reseña.delete()
        messages.success(request, '¡Reseña eliminada exitosamente!')
        
    except Reseña.DoesNotExist:
        messages.error(request, 'La reseña no existe')
    except Exception as e:
        messages.error(request, f'Error al eliminar reseña: {str(e)}')
    
    return redirect('mis_resenas_cliente')