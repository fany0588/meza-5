# app_famfashion/context_processors.py
def cliente_context(request):
    return {
        'cliente_autenticado': bool(request.session.get('cliente_id')),
        'cliente_nombre': request.session.get('cliente_nombre', ''),
        'cliente_id': request.session.get('cliente_id'),
    }